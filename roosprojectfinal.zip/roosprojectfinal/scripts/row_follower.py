#!/usr/bin/env python3
import rospy, time
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan

# ===== TUNABLE PARAMETERS =====
LINEAR_SPEED = 0.22        
TURN_SPEED   = 0.6         # Turning speed
FORWARD_TIME = 1.2         # Row khatam honay ke baad kitna mazeed agay jana hai
TURN_TIME    = 5.4         # 180 degree turn ke liye time (isay adjust karein)

KP = 0.25                  
MAX_ANG = 0.4
DEAD_ZONE = 0.08           

# Detection Thresholds
ROW_END_GAP = 2.0          # Agar right side distance 2m se barh jaye to matlab row khatam
DESIRED_RIGHT_DIST = 0.75  
# ==============================

class RowFollower:
    def __init__(self):
        self.pub = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
        self.sub = rospy.Subscriber("/scan", LaserScan, self.scan_cb)
        
        # States: FOLLOWING, CLEARING, TURNING
        self.state = "FOLLOWING" 
        self.state_start_time = 0.0

    def scan_cb(self, scan):
        cmd = Twist()
        now = time.time()

        # LiDAR setup (Assuming 0 is front, 270 is right)
        front = min(scan.ranges[0:15] + scan.ranges[-15:])
        right = min(scan.ranges[250:290])

        if self.state == "FOLLOWING":
            # 1. Detection: Agar samnay rasta band ho ya side se crop khatam ho jaye
            if front < 0.6 or right > ROW_END_GAP:
                rospy.loginfo("Row End Detected! Clearing the corner...")
                self.state = "CLEARING"
                self.state_start_time = now
                return

            # 2. Normal Row Following logic
            error = DESIRED_RIGHT_DIST - right
            steer = 0.0 if abs(error) < DEAD_ZONE else max(-MAX_ANG, min(MAX_ANG, KP * error))
            
            cmd.linear.x = LINEAR_SPEED
            cmd.angular.z = steer

        elif self.state == "CLEARING":
            # Thora agay jana taake safe turn ho sakay
            cmd.linear.x = LINEAR_SPEED
            cmd.angular.z = 0.0
            if now - self.state_start_time > FORWARD_TIME:
                rospy.loginfo("Starting U-Turn...")
                self.state = "TURNING"
                self.state_start_time = now

        elif self.state == "TURNING":
            # 180 Degree U-Turn (Right side turn)
            cmd.linear.x = 0.1 
            cmd.angular.z = -TURN_SPEED # Minus sign for right turn
            
            if now - self.state_start_time > TURN_TIME:
                rospy.loginfo("Turn Complete. Re-entering row...")
                self.state = "FOLLOWING"

        self.pub.publish(cmd)

if __name__ == '__main__':
    try:
        rospy.init_node("row_follower_v2")
        RowFollower()
        rospy.loginfo("Agribot Row Follower Started")
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
