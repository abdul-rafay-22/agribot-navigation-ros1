#!/usr/bin/env python3
import rospy
from visualization_msgs.msg import Marker, MarkerArray

rospy.init_node("plant_health_markers")
pub = rospy.Publisher("/plant_health", MarkerArray, queue_size=1)

rate = rospy.Rate(1)

def marker(mid, y, color):
    m = Marker()
    m.header.frame_id = "odom"   # IMPORTANT FIX
    m.header.stamp = rospy.Time.now()
    m.ns = "plants"
    m.id = mid
    m.type = Marker.CUBE
    m.action = Marker.ADD

    m.pose.position.x = 0
    m.pose.position.y = y
    m.pose.position.z = 0.25

    m.scale.x = 30
    m.scale.y = 0.5
    m.scale.z = 0.5

    m.color.r, m.color.g, m.color.b = color
    m.color.a = 1.0
    return m

rospy.loginfo("Plant health markers started")

while not rospy.is_shutdown():
    arr = MarkerArray()
    arr.markers.append(marker(0,  0, (0,1,0)))
    arr.markers.append(marker(1,  2, (1,1,0)))
    arr.markers.append(marker(2,  4, (1,0,0)))
    arr.markers.append(marker(3,  6, (0,1,0)))
    arr.markers.append(marker(4,  8, (1,1,0)))
    arr.markers.append(marker(5, 10, (1,0,0)))

    pub.publish(arr)
    rate.sleep()

